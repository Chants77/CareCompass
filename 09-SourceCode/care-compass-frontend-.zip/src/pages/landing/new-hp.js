import React, { useEffect } from "react"
import "./newHp.css"
import { Row, Col } from 'antd';
import { Input, Text, Link ,Box} from "@chakra-ui/react";
import Conferences from "./conferences";
import Papers from "./paper";
import MyHeader from "../../components/header/header";

function NewHp() {

}

export default NewHp
