import time
from django.core import signing
import hashlib
import datetime
from User.models import User

HEADER = {'typ': 'JWP', 'alg': 'default'}
KEY = 'CHEN_FENG_YAO'
SALT = 'www.lanou3g.com'


def encrypt(obj):
    """加密"""
    value = signing.dumps(obj, key=KEY, salt=SALT)
    value = signing.b64_encode(value.encode()).decode()
    return value


def decrypt(src):
    """解密"""
    src = signing.b64_decode(src.encode()).decode()
    raw = signing.loads(src, key=KEY, salt=SALT)
    return raw


# def create_token(username):
#     """生成token信息"""
#     # 1. 加密头信息
#     header = encrypt(HEADER)
#     # # 2. 构造Payload
#     # payload = {"username": username, "iat": time.time()}
#     payload={"username":username}
#     payload = encrypt(payload)
#     # 3. 生成签名
#     md5 = hashlib.md5()
#     md5.update(("%s.%s" % (header, payload)).encode())
#     signature = md5.hexdigest()
#     token = "%s.%s.%s" % (header, payload, signature)
#     return token

def create_token(username):
    """生成token信息"""
    # 1. 加密头信息
    # header = encrypt(HEADER)
    # # 2. 构造Payload
    # payload = {"username": username, "iat": time.time()}
    payload = {"username": username, "iat": time.time()}
    payload = encrypt(payload)
    # 3. 生成签名
    md5 = hashlib.md5()
    md5.update(payload.encode())
    signature = md5.hexdigest()
    token = "%s.%s" % (payload, signature)
    return token


def get_payload(token):
    payload = str(token).split('.')[0]
    payload = decrypt(payload)
    return payload


# 通过token获取用户名
def get_username(token):
    payload = get_payload(token)
    return payload['username']


# 通过username和token获取用户，若没有则返回None
def check_token(token):
    username = get_username(token)
    check_user = User.objects.filter(username=username, token=token)
    # check_user = User.objects.filter(username=username, isBan=0)
    if check_user.count() > 0:
        return check_user[0]
    return None


# 为时间增加八个小时
def addhours(t):
    return t + datetime.timedelta(hours=8)
