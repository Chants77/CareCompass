from django.urls import path

from .views import *

urlpatterns = [
    # 登录
    path('login/', UserViewSet.as_view({'post': 'login'})),
    # 注册
    path('register/', UserViewSet.as_view({'post': 'register'})),
    path('register/doctor/', UserViewSet.as_view({'post': 'registerDoctor'})),
    # 忘记密码短信验证
    path('verifycode/', UserViewSet.as_view({'post': 'getVerifyCode'})),
    path('resetcode/', UserViewSet.as_view({'post': 'resetCode'})),
    # 找回密码，返回用户密码
    path('patient/edit/', UserViewSet.as_view({'post': 'editPatient'})),
    path('doctor/edit/', UserViewSet.as_view({'post': 'editDoctor'})),
    path('patient/defaultedAppointmentsCheck/', UserViewSet.as_view({'post': 'checkIsBan'})),
    # 患者信息
    path('patient/info/', UserViewSet.as_view({'post': 'getPatient'})),
    path('doctor/info/', UserViewSet.as_view({'post': 'getDoctor'})),
    path('doctor/add/', UserViewSet.as_view({'post': 'insertDoctor'})),
    path('patient/add/', UserViewSet.as_view({'post': 'insertPatient'})),
    path('doctor/edit/price/', UserViewSet.as_view({'post': 'editPrice'})),
]
