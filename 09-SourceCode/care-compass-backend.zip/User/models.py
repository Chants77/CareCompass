from datetime import datetime

from django.db import models
from django.utils import timezone


class Department(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255, verbose_name=u'名称')
    introduction = models.CharField(max_length=4095, verbose_name=u'简介', null=True)


class User(models.Model):
    gender_choices = (
        ('male', '男'),
        ('female', '女'),
    )
    identity_choices = (
        ('patient', 1),
        ('doctor', 2),
        ('super_user', 0),
    )

    id = models.AutoField(primary_key=True)
    username = models.CharField(verbose_name=u"用户名", max_length=30)
    password = models.CharField(verbose_name=u"密码", max_length=30)
    identity = models.CharField(max_length=50, verbose_name=u"身份", choices=identity_choices, default='student')
    gender = models.CharField(max_length=50, verbose_name=u"性别", choices=gender_choices, default='male')
    officialID = models.CharField(max_length=50, verbose_name=u'身份证号', default='')
    phone = models.CharField(max_length=50, verbose_name=u'手机号', default='')
    email = models.EmailField(verbose_name=u'邮箱', default='')
    missCount = models.IntegerField(verbose_name=u'失约次数', default=0)
    isBan = models.IntegerField(default=0)  # 是否被禁用，0表示没有，1表示被禁用
    token = models.CharField('token', max_length=255, default="")
    last_login = models.DateTimeField("最近登录时间", default=timezone.now)

    objects = models.Manager()

    class Meta:
        verbose_name = '用户信息'
        verbose_name_plural = verbose_name


class LoginTime(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='登录用户')
    log_time = models.DateTimeField(verbose_name='登录时间', default=timezone.now)


class Doctor(models.Model):
    id = models.AutoField(primary_key=True)
    workID = models.CharField(max_length=50, verbose_name=u'工号')
    user = models.ForeignKey(User, verbose_name='账号', on_delete=models.CASCADE)
    title = models.CharField(max_length=50, verbose_name=u"职称", default='医师')
    intro = models.CharField(max_length=4095, verbose_name=u'介绍', default='')
    area = models.CharField(max_length=4095, verbose_name=u'专业领域', default='')
    department = models.ForeignKey(Department, verbose_name=u'所属科室', on_delete=models.CASCADE)
    price = models.FloatField(verbose_name=u'挂号费', default=50)
    count = models.IntegerField(verbose_name=u'累计挂号量', default=0)


class Bill(models.Model):
    id = models.AutoField(primary_key=True)
    price = models.FloatField(verbose_name=u'金额', default=0)
    create_time = models.DateTimeField(verbose_name=u'创建时间', default=timezone.now)
    pay_time = models.DateTimeField(verbose_name=u'支付时间', null=True)


class VerifyCode(models.Model):
    id = models.AutoField(primary_key=True)
    phone = models.CharField(max_length=15, verbose_name=u'手机号')
    code = models.CharField(max_length=10, verbose_name=u'验证码')
    time = models.DateTimeField(verbose_name=u'发送时间', default=timezone.now)
