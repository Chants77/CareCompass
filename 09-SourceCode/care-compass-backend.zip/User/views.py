import json
import traceback
import requests
import CareCompass.settings

from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views import View
from rest_framework import viewsets
from rest_framework.response import Response
from django.utils import timezone

from Consultation.models import Appointment
from .models import *
from .jwt_token import *
from datetime import datetime, timedelta
import random
from .message import *
from django.core.cache import cache
from django.db import connection, transaction
from django.db.models import Count
from django.core.paginator import Paginator


# from Work.api import removeSubmissions
def getSex(officialID):
    return (int(officialID[16]) & 1) == 1


class UserViewSet(viewsets.ModelViewSet):
    """
    A viewset that provides the standard actions
    """
    queryset = User.objects.all()

    def login(self, request):
        result = {"code": 401, "msg": "账号或密码错误", "content": {}}
        user_id = request.data["officialID"]
        password = request.data["password"]
        try:
            if len(user_id) == 18:
                user = User.objects.get(officialID=user_id, password=password, isBan=0)
            elif user_id == "admin":
                user = User.objects.get(id=23, password=password)
            else:
                user = Doctor.objects.get(workID=user_id, user__password=password).user
            token = create_token(user.username)
            user.token = token
            user.last_login = timezone.now()
            user.save()
            result = {'code': 200, 'msg': '登录成功', "token": token, "userID": user.id,
                      "type": user.get_identity_display(), "username": user.username}
            if len(user_id) == 8:
                doctor = Doctor.objects.get(workID=user_id)
                result['doctorID'] = doctor.id
            LoginTime.objects.create(user=user)
        except:
            pass
        return Response(result)

    def register(self, request):
        result = {"code": 200, "msg": "注册成功", "content": {}}
        try:
            data = request.data
            old = User.objects.filter(officialID=data["officialID"], identity='patient')
            if old.exists():
                result["code"] = 401
                result["msg"] = "用户已注册"
            else:
                sex = "male" if getSex(data['officialID']) else 'female'
                verify = VerifyCode.objects.get(phone=data.get('phone'))
                if int(verify) == int(data['verifyCode']):
                    user = User.objects.create(username=data["username"], officialID=data["officialID"],
                                               password=data["password"], phone=data.get('phone'), gender=sex,
                                               identity="patient")
                    token = create_token(user.username)
                    user.token = token
                    user.save()
                    result["content"] = {"token": token, "userID": user.id}
                else:
                    result['code'] = 402
                    result['msg'] = "验证码错误"
        except:
            traceback.print_exc()
            result["code"] = 403
            result["msg"] = "参数错误"
            return Response(result)
        return Response(result)

    @transaction.atomic
    def registerDoctor(self, request):
        result = {"code": 200, "msg": "注册成功", "content": {}}
        try:
            data = request.data
            old = Doctor.objects.filter(id=data.get('workID'))
            if old.exists():
                result["code"] = 401
                result["msg"] = "用户已注册"
            else:
                sex = 'male' if getSex(data.get('officialID')) else 'female'
                # verify = VerifyCode.objects.get(phone=data.get('phone'))
                user = User.objects.create(username=data.get('username'), officialID=data.get('officialID'),
                                           password=data.get('workID'),
                                           phone=data.get('phone'), gender=sex, identity="doctor")
                token = create_token(user.username)
                user.token = token
                user.save()
                department = Department.objects.get(id=data.get('departmentID'))
                price = float(data.get('price'))
                doctor = Doctor.objects.create(user=user, title=data.get('title'), workID=data.get("workID"),
                                               area=data.get('area'), department=department, intro=data.get('intro'),
                                               price=price)
                doctor.save()
                result["content"] = {"token": token, "userID": user.id}
        except:
            traceback.print_exc()
            result["code"] = 403
            result["msg"] = "参数错误"
            return Response(result)
        return Response(result)

    @transaction.atomic
    def getVerifyCode(self, request):
        phone = request.data.get('phone')
        if VerifyCode.objects.filter(phone=phone, time__gte=timezone.now() - timedelta(minutes=1)).count() > 0:
            return Response({'code': 400, 'msg': '每分钟只能发送一条短信'})
        VerifyCode.objects.filter(phone=phone).delete()
        code = str(random.randint(100, 999)) + str(random.randint(100, 999))
        entity = SMS(ACCESSKEYID="LTAI5tN3GqhUNDYdnbgSi5V4",
                     ACCESSSECRET="xwDtL9lQc8wCxHELC36XcWJMg7gppb", SIGN_NAME="CareCompass")
        _tpl_code = "SMS_460940102"
        _tpl_params = {"code": code}
        result = entity.send_sms(phone, _tpl_code, _tpl_params)
        VerifyCode.objects.create(phone=phone, code=code)
        return Response({'code': 200, 'msg': 'success', 'result': result})

    @transaction.atomic
    def verify(self, user, verifyCode):
        VerifyCode.objects.filter(phone=user.phone, code=verifyCode,
                                  time__lt=timezone.now() - timedelta(minutes=1)).delete()
        if VerifyCode.objects.filter(phone=user.phone, code=verifyCode,
                                     time__gte=timezone.now() - timedelta(minutes=1)).count() == 0:
            return False
        VerifyCode.objects.filter(phone=user.phone).delete()
        return True

    @transaction.atomic
    def resetCode(self, request):
        user = User.objects.get(id=request.uid)
        # VerifyCode.objects.filter(phone=user.phone, code=request.data['verify'],
        #                           time__lt=timezone.now() - timedelta(minutes=1)).delete()
        # if VerifyCode.objects.filter(phone=user.phone, code=request.data['verify'], time__gte=timezone.now()-timedelta(minutes=1)).count() == 0:
        #     return Response({'code': 400, 'msg': '验证码不正确或短信已过期'})
        # VerifyCode.objects.filter(phone=user.phone).delete()
        if self.verify(user, request.data.get('verify')):
            return Response({'code': 400, 'msg': '验证码不正确或短信已过期'})
        user.password = request.data['password']
        user.save()
        return Response({'code': 200, 'msg': 'success'})

    def getPatient(self, request):
        ret = {'code': 200, 'msg': 'success'}
        try:
            stu = User.objects.get(pk=int(request.data.get('UserID')))
        except:
            ret['code'] = 201
            ret['msg'] = '用户不存在'
        else:
            ret['name'] = stu.username
            ret['officialID'] = stu.officialID
            ret['phone'] = stu.phone
            ret['email'] = stu.email
            ret['sex'] = stu.gender
            ret['password'] = stu.password
            ret['identity'] = stu.identity

        return Response(ret)

    def checkIsBan(self, request):
        user = User.objects.get(id=request.uid)
        user.isBan = Appointment.objects.filter(patient=user,
                                                appointTime__date__gte=timezone.now() - timedelta(days=30),
                                                isOnTime=False).count() >= 5
        user.save()
        return Response({'isDefaulted': user.isBan})

    def getDoctor(self, request):
        id = request.data.get('doctorID')
        ret = {'code': 200, 'msg': 'success'}
        try:
            doctor = Doctor.objects.get(id=id)
        except:
            ret['code'] = 400
            ret['msg'] = '医生不存在'
        else:
            ret['content'] = {
                'name': doctor.user.username,
                'departmentID': doctor.department.id,
                'departmentName': doctor.department.name,
                'title': doctor.title,
                'totalCount': doctor.count,
                'intro': doctor.intro
            }
        return Response(ret)

    def editPatient(self, request):
        ret = {'code': 200, 'msg': '修改成功'}
        try:
            stu = User.objects.get(pk=int(request.uid))
        except:
            ret['code'] = 400
            ret['msg'] = '用户不存在'
        else:
            if request.data.get('phone') and request.data.get('verifyCode'):
                if self.verify(stu, request.data.get('verifyCode')):
                    return Response({'code': 400, 'msg': '验证码不正确或短信已过期'})
                stu.phone = request.data['phone']
            if request.data.get('password'):
                stu.password = request.data['password']
            if request.data.get('email'):
                stu.email = request.data['email']
            stu.save()
        return Response(ret)

    def editDoctor(self, request):
        ret = {'code': 200, 'msg': '修改成功'}
        try:
            stu = Doctor.objects.get(pk=int(request.data.get('doctorID')))
        except:
            ret['code'] = 400
            ret['msg'] = '医生不存在'
        else:
            if User.objects.get(id=request.uid).identity == 'patient' \
                    or stu.user.id != request.uid:
                ret = {'code': 400, 'msg': '无权限'}
                return Response(ret)
            if request.data.get('title'):
                stu.title = request.data['title']
            if request.data.get('intro'):
                stu.intro = request.data['intro']
            if request.data.get('departmentID'):
                stu.department = Department.objects.get(request.data['departmentID'])
            if request.data.get('price'):
                stu.price = request.data.get('price')
            stu.save()
        return Response(ret)

    def insertDoctor(self, request):

        import openpyxl
        def read_xlsx(file_name):
            workbook = openpyxl.load_workbook(file_name)
            sheet = workbook.active

            data = []
            for row in sheet.iter_rows(values_only=True):
                record = {"name": row[0], "birthday": row[1], "sex": row[2]}
                data.append(record)

            return data

        file_name = "/Users/liuhongyu/Projects/Python/CareCompass/User/doctors.xlsx"
        data = read_xlsx(file_name)
        countDic = dict()
        for key in range(1, 29):
            countDic[key] = 2
        countDic[1] += 8
        countDic[2] += 6
        departments = []
        for k, v in countDic.items():
            departments.extend([k] * v)
        for person, departmentID in zip(data, departments):
            officialID = str(random.randint(110101, 490873)) + str(person.get('birthday')) + str(random.randint(0, 99)) \
                         + str(0 if person['sex'] == 'female' else 1) + str(random.randint(1, 9))
            count = Doctor.objects.filter(department__id=departmentID).count() + 1
            workID = str(23) + ("0" if departmentID < 10 else "") + str(departmentID) + "00" \
                     + ('0' if count < 10 else "") + str(count)

            user = User.objects.create(username=person.get('name'), officialID=officialID,
                                       password=workID,
                                       phone="137" + str(person.get('birthday')), gender=person.get('sex'),
                                       identity="doctor")
            token = create_token(user.username)
            user.token = token
            user.save()
            department = Department.objects.get(id=departmentID)
            price = float(random.randint(39, 299))
            doctor = Doctor.objects.create(user=user, workID=workID,
                                           area=department.introduction + '的医生', department=department,
                                           intro='我是' + person['name'],
                                           price=price)
            doctor.save()

        return Response({'code': 200})

    def insertPatient(self, request):

        import openpyxl
        def read_xlsx(file_name):
            workbook = openpyxl.load_workbook(file_name)
            sheet = workbook.active

            data = []
            for row in sheet.iter_rows(values_only=True):
                record = {"name": row[0], "birthday": row[1], "sex": row[2]}
                data.append(record)

            return data

        file_name = "/Users/liuhongyu/Projects/Python/CareCompass/User/patient.xlsx"
        data = read_xlsx(file_name)
        for person in data:
            officialID = str(random.randint(110101, 490873)) + str(person.get('birthday')) + str(random.randint(0, 99)) \
                         + str(0 if person['sex'] == 'female' else 1) + str(random.randint(1, 9))
            user = User.objects.create(username=person.get('name'), officialID=officialID,
                                       password='88888888',
                                       phone="137" + str(person.get('birthday')), gender=person.get('sex'),
                                       identity="doctor")
            token = create_token(user.username)
            user.token = token
            user.save()
        return Response({'code': 200})

    def editPrice(self, requset):
        for departmentID in range(1, 29):
            price = 199
            for doctor in Doctor.objects.filter(department__id=departmentID).order_by('id'):
                doctor.price = price
                price = round(price * 0.7) if price * 0.7 > 39 else price
                doctor.save()
        return Response({"code": 200})

    '''
    忘记密码，短信验证函数
    发送五位随机数，两次信息间隔半分钟，国内短信
    发送成功后，将用户id，验证码作为键值对存入redis，五分钟过期
    '''

    # def forgetcode(self, request):
    #     data = request.data
    #     user = User.objects.filter(student_ID=data["stuId"], username=data["stuName"], phone=data["phone"])
    #     if user.exists():
    #         code = str(random.randint(10000, 99999))
    #         res = send_sms_single(data["phone"], "1340656", [code])
    #         if res["result"] != 0:
    #             result = {"code": 401, "msg": "手机号不合法，信息发送出错"}
    #         else:
    #             cache.set(data["stuId"], code, 5 * 60)
    #             cache.set(code, user[0].id, 5 * 60)
    #             result = {"code": 200, "msg": "信息发送成功"}
    #
    #     else:
    #         result = {"code": 400, "msg": "信息不匹配"}
    #
    #     return JsonResponse(result)
