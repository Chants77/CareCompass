from django.urls import path

from .views import *

urlpatterns = [
    path('treatment/getWorkShiftInfo/', TreatmentViewSet.as_view({'post': 'getWorkShiftInfo'})),
    path('treatment/getHistoryRecord/', TreatmentViewSet.as_view({'post': 'getHistoryRecords'})),
    path('treatment/getHistoryRecord/single/', TreatmentViewSet.as_view({'post': 'getRecord'})),
    path('treatment/getPatientList/', TreatmentViewSet.as_view({'post': 'getPatientList'})),
    path('treatment/searchPrescription/', TreatmentViewSet.as_view({'post': 'searchPrescription'})),
    path('treatment/searchInspection/', TreatmentViewSet.as_view({'post': 'searchInspection'})),
    path('treatment/createMedicalRecord/', TreatmentViewSet.as_view({'post': 'createMedicalRecord'})),
    path('treatment/createPrescriptionForm/', TreatmentViewSet.as_view({'post': 'createPrescriptionForm'})),
    path('treatment/createInspectionForm/', TreatmentViewSet.as_view({'post': 'createInspectionForm'})),
    path('treatment/applyLeave/', TreatmentViewSet.as_view({'post': 'applyLeave'})),
    path('treatment/getDocAllLeave/', TreatmentViewSet.as_view({'post': 'getDocAllLeave'})),
]
