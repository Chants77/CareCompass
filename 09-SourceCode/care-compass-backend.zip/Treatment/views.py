from datetime import datetime, timedelta

from django.db import transaction
from rest_framework import viewsets
from Admin.models import *
from Consultation.models import *
from rest_framework.response import Response


class TreatmentViewSet(viewsets.ModelViewSet):
    def getHistoryRecords(self, request):
        ret = dict()
        try:
            data = request.data
            patientID = data.get('patientID')
            recordList = list()
            for record in MedicalRecord.objects.filter(appointment__patient__id=patientID):
                doctor = record.appointment.doctor
                item = {"id": record.record_id, "diagnose": record.diagnose, "description": record.description,
                        "date": record.appointment.appointTime.date.strftime("%Y-%m-%d"),
                        "time": record.appointment.appointTime.time}
                item.update({"departmentName": doctor.department.name, "departmentID": doctor.department.id})
                item.update({"doctorName": doctor.user.username, "doctorID": doctor.id, "doctorWorkID": doctor.workID})
                prescriptionList = list()
                inspectionList = list()
                for p in PrescriptionForm.objects.filter(medical_record__record_id=record.record_id):
                    pItem = dict()
                    pItem["prescriptionName"] = Prescription.objects.get(prescription_id=p.id).prescription_name
                    pItem["prescriptionNum"] = p.number
                    pItem["description"] = p.description
                    prescriptionList.append(pItem)
                for i in InspectionForm.objects.filter(medical_record__record_id=record.record_id):
                    inspectionList.append(Inspection.objects.get(inspection_id=i.inspection_id).inspection_name)
                item["prescriptionList"] = prescriptionList
                item["inspectionList"] = inspectionList
                recordList.append(item)
            ret["data"] = {
                "patientName": User.objects.get(id=patientID).username,
                "recordList": recordList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)
        return Response(ret)

    def getRecord(self, request):
        ret = dict()
        try:
            data = request.data
            patientID = data.get('patientID')
            recordList = list()
            for record in MedicalRecord.objects.filter(record_id=data['recordID']):
                doctor = record.appointment.doctor
                item = {"id": record.record_id, "diagnose": record.diagnose, "description": record.description,
                        "date": record.appointment.appointTime.date.strftime("%Y-%m-%d"),
                        "time": record.appointment.appointTime.time}
                item.update({"departmentName": doctor.department.name, "departmentID": doctor.department.id})
                item.update({"doctorName": doctor.user.username, "doctorID": doctor.id, "doctorWorkID": doctor.workID})
                prescriptionList = list()
                inspectionList = list()
                for p in PrescriptionForm.objects.filter(medical_record__record_id=record.record_id):
                    pItem = dict()
                    pItem["prescriptionName"] = Prescription.objects.get(prescription_id=p.id).prescription_name
                    pItem["prescriptionNum"] = p.number
                    pItem["description"] = p.description
                    prescriptionList.append(pItem)
                for i in InspectionForm.objects.filter(medical_record__record_id=record.record_id):
                    inspectionList.append(Inspection.objects.get(inspection_id=i.inspection_id).inspection_name)
                item["prescriptionList"] = prescriptionList
                item["inspectionList"] = inspectionList
                recordList.append(item)
            data = {
                "patientName": User.objects.get(id=patientID).username,
                "record": recordList[0]
            }
            ret["data"] = data
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)
        return Response(ret)

    def getPatientList(self, request):
        ret = dict()
        try:
            data = request.data
            doctorID = data.get("doctorID")
            date = datetime.strptime(data.get("date"), "%Y-%m-%d")
            time = int(data.get("time"))  # 0-上午,1-下午
            doctor = Doctor.objects.get(id=doctorID)
            patientList = list()
            for appointment in Appointment.objects.filter(doctor=doctor,
                                                          appointTime__date=date,
                                                          appointTime__time=time).order_by("appointTime"):
                isEnd = MedicalRecord.objects.filter(appointment=appointment).count()
                item = dict()
                item["patientID"] = appointment.patient.id
                item["appointmentID"] = appointment.id
                item["name"] = appointment.patient.username
                item["gender"] = appointment.patient.gender
                item["date"] = str(appointment.appointTime.date)
                item["isEnd"] = 0 if isEnd == 0 else 1
                patientList.append(item)
            ret["data"] = {
                "patientList": patientList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getWorkShiftInfo(self, request):
        ret = dict()
        try:
            data = request.data
            doctorID = data.get("doctorID")
            doctor = Doctor.objects.get(id=doctorID)
            minDate = datetime.today()
            maxDate = minDate + timedelta(days=30)
            shiftList = list()
            for workShift in DoctorWorkShift.objects.exclude(state=1).filter(doctor=doctor,
                                                                             shift__date__gte=minDate,
                                                                             shift__date__lte=maxDate,
                                                                             state=0)\
                    .order_by("shift__date", "shift__time"):
                item = dict()
                item["id"] = workShift.id
                item["date"] = str(workShift.shift.date)
                item["time"] = workShift.shift.time
                item["num"] = workShift.total - workShift.available
                shiftList.append(item)
            ret["data"] = {
                "shiftList": shiftList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def searchPrescription(self, request):
        ret = dict()
        try:
            data = request.data
            msg = data.get("msg")
            prescriptionList = list()
            for p in Prescription.objects.filter(prescription_name__contains=msg):
                item = dict()
                item["id"] = p.prescription_id
                item["name"] = p.prescription_name
                item["price"] = p.prescription_price
                prescriptionList.append(item)
            ret["data"] = {
                "prescriptionList": prescriptionList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def searchInspection(self, request):
        ret = dict()
        try:
            data = request.data
            msg = data.get("msg")
            inspectionList = list()
            for i in Inspection.objects.filter(inspection_name__contains=msg):
                item = dict()
                item["id"] = i.inspection_id
                item["name"] = i.inspection_name
                item["price"] = i.inspection_price
                inspectionList.append(item)
            ret["data"] = {
                "inspectionList": inspectionList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    @transaction.atomic
    def createMedicalRecord(self, request):
        ret = dict()
        try:
            data = request.data
            appointmentID = data.get("appointmentID")
            description = data.get("description")
            diagnose = data.get("diagnose")
            appointment = Appointment.objects.get(id=appointmentID)
            record = MedicalRecord.objects.create(appointment=appointment, description=description, diagnose=diagnose)
            ret["data"] = {
                "recordID": record.record_id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    @transaction.atomic
    def createPrescriptionForm(self, request):
        ret = dict()
        try:
            data = request.data
            recordID = data.get("recordID")
            prescriptionID = data.get("prescriptionID")
            description = data.get("description")
            num = data.get("num")
            if num <= 0:
                raise Exception("处方数量不得为负")
            record = MedicalRecord.objects.get(record_id=recordID)
            prescription = Prescription.objects.get(prescription_id=prescriptionID)
            price = num * prescription.prescription_price
            bill = Bill.objects.create(price=price)
            prescriptionForm = PrescriptionForm.objects.create(prescription_id=prescription, number=num,
                                                               bill=bill, medical_record=record,
                                                               description=description)
            ret["data"] = {
                "formID": prescriptionForm.id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    @transaction.atomic
    def createInspectionForm(self, request):
        ret = dict()
        try:
            data = request.data
            recordID = data.get("recordID")
            inspectionID = data.get("inspectionID")
            description = data.get("description")
            inspection = Inspection.objects.get(inspection_id=inspectionID)
            record = MedicalRecord.objects.get(record_id=recordID)
            bill = Bill.objects.create(price=inspection.inspection_price)
            inspectionForm = InspectionForm.objects.create(inspection_id=inspection,
                                                           bill=bill,
                                                           medical_record=record,
                                                           description=description)
            ret["data"] = {
                "formID": inspectionForm.id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def applyLeave(self, request):
        ret = dict()
        try:
            data = request.data
            shiftID = data.get("shiftID")
            doctorShift = DoctorWorkShift.objects.get(id=shiftID)
            apply_type = int(data.get("type"))
            if apply_type not in [0, 1]:
                print(apply_type)
                raise Exception("请假类型非法")
            reason = data.get("reason")
            app = LeaveApplication.objects.create(doctor_shift=doctorShift,
                                                  apply_type=apply_type,
                                                  reason=reason)
            ret["data"] = {
                "appID": app.id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getDocAllLeave(self, request):
        ret = dict()
        try:
            data = request.data
            doctorID = data.get("doctorID")
            doctor = Doctor.objects.get(id=doctorID)
            leaveList = list()
            for l in LeaveApplication.objects.filter(doctor_shift__doctor=doctor):
                leaveList.append({
                    "id": l.id,
                    "doctorShiftID": l.doctor_shift.id,
                    "type": l.apply_type,
                    "state": l.state,
                    "reason": l.reason,
                    "commitTime": str(l.commitTime.strftime("%Y-%m-%d %H:%M:%S")) if l.commitTime else None,
                    "verifyTime": str(l.verifyTime.strftime("%Y-%m-%d %H:%M:%S")) if l.verifyTime else None,
                    "verifyComment": l.verifyComment

                })
            ret["data"] = {
                "leaveList": leaveList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)
