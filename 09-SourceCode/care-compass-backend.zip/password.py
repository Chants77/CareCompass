k1, k2 = 7, 3
msg = "cryptographyisthescienceandstudyofsecretwriting"
table: list


def getTable(method):
    global table
    table = [chr(ord('a') + (i * k1 + k2) % 26) for i in range(26)]
    method()
    print("Done.")


@getTable
def crypt():
    ans = ''
    global table
    for c in msg:
        ans += table[(ord(c) - ord('a'))]
    return ans


if __name__ == '__main__':
    print(crypt())
