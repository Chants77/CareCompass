from django.utils import timezone

from django.db import models

from User.models import Bill, Department
from Consultation.models import Appointment, DoctorWorkShift


# 病历表
class MedicalRecord(models.Model):
    record_id = models.AutoField(primary_key=True, verbose_name="病历编号")
    # disease = models.CharField(max_length=255, default='', verbose_name=u'诊断')
    description = models.CharField(max_length=4096, default=' ', verbose_name="病历详情")
    diagnose = models.CharField(max_length=4096, default=' ', verbose_name="病历详情")
    appointment = models.ForeignKey(Appointment, verbose_name="挂号", on_delete=models.CASCADE)
    # date = models.DateField(verbose_name="就诊日期", default=timezone.now)  # 排班日期
    # time = models.IntegerField(verbose_name="时间段")  # 0-上午，1-下午


# 处方表
class Prescription(models.Model):
    prescription_id = models.AutoField(primary_key=True, verbose_name="处方编号")
    approval_number = models.CharField(max_length=50, verbose_name="批准文号")
    prescription_name = models.CharField(max_length=50, default=' ', verbose_name="处方名称")
    production_unit = models.CharField(max_length=50, default=' ', verbose_name="生产单位")
    prescription_price = models.FloatField(verbose_name="处方价格")


# 处方单表
class PrescriptionForm(models.Model):
    id = models.AutoField(primary_key=True)
    prescription_id = models.ForeignKey(Prescription, on_delete=models.CASCADE)
    number = models.IntegerField(default=1)
    # total_price = models.FloatField()
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE)
    description = models.CharField(max_length=4096, default='', verbose_name="注意事项")
    medical_record = models.ForeignKey(MedicalRecord, verbose_name="病历", on_delete=models.CASCADE)
    # prescription = models.ForeignKey(Prescription, verbose_name="处方", on_delete=models.CASCADE)


# 检查表
class Inspection(models.Model):
    inspection_id = models.AutoField(primary_key=True, verbose_name="检查编号")
    inspection_name = models.CharField(max_length=50, default=' ', verbose_name="检查名称")
    inspection_price = models.FloatField(verbose_name="检查价格")
    department = models.ForeignKey(Department, verbose_name=u'所属科室', on_delete=models.CASCADE)
    detail = models.CharField(max_length=4096, default='', verbose_name="详细描述")


# 检查单表
class InspectionForm(models.Model):
    id = models.AutoField(primary_key=True)
    inspection_id = models.ForeignKey(Inspection, on_delete=models.CASCADE)
    # price = models.FloatField()
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE)
    medical_record = models.ForeignKey(MedicalRecord, verbose_name="病历", on_delete=models.CASCADE)
    description = models.CharField(max_length=4096, default='', verbose_name="注意事项")
    # inspection = models.ForeignKey(Inspection, verbose_name="检查")


class LeaveApplication(models.Model):
    id = models.AutoField(primary_key=True)
    doctor_shift = models.ForeignKey(DoctorWorkShift, on_delete=models.CASCADE)
    apply_type = models.IntegerField(verbose_name="请假类型", default=0) # 0-事假，1-病假
    state = models.IntegerField(verbose_name="审核状态", default=0) # 0-待审核，1-审核通过，2-审核不通过
    reason = models.CharField(max_length=4095, default=' ', verbose_name="请假理由")
    commitTime = models.DateTimeField("申请时间", default=timezone.now)
    verifyComment = models.CharField(max_length=4095, default=' ', verbose_name="审核意见")
    verifyTime = models.DateTimeField("审核时间", null=True)


class Notification(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=4096, verbose_name=u'标题')
    content = models.CharField(max_length=4096,verbose_name=u'正文')
    time = models.DateTimeField(verbose_name=u'发布时间', default=timezone.now)
    type = models.IntegerField(verbose_name=u'类型', default=0)


# class Promotion(models.Model):
#     id = models.AutoField(primary_key=True)
#     title = models.CharField(max_length=4096, verbose_name=u'标题')
#     content = models.CharField(max_length=4096, verbose_name=u'正文')
#     time = models.DateTimeField(verbose_name=u'发布时间', default=timezone.now)
