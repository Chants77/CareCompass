from datetime import datetime, timedelta
import calendar

from django.db import transaction
from django.db.models import Sum, F
from rest_framework import viewsets
from Admin.models import *
from Consultation.models import *
from rest_framework.response import Response
from User.models import *


class AdminViewSet(viewsets.ModelViewSet):
    def createDepartment(self, request):
        ret = dict()
        try:
            data = request.data
            name = data.get("name")
            intro = data.get("intro")
            if not name:
                raise Exception("部门名字不能为空")
            department = Department.objects.create(name=name, introduction=intro)
            ret["data"] = {
                "id": department.id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def updateDepartment(self, request):
        ret = dict()
        try:
            data = request.data
            did = data.get("id")
            name = data.get("name")
            intro = data.get("intro")
            if not name:
                raise Exception("部门名字不能为空")
            department = Department.objects.get(id=did)
            department.name = name
            department.introduction = intro
            department.save()
            ret["data"] = {
                "id": department.id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getAllDoctor(self, departmentID):
        ret = list()
        for d in Doctor.objects.filter(department__id=departmentID):
            ret.append({
                "doctorID": d.id,
                "doctorName": d.user.username
            })

        return ret

    def getAllDepartment(self, request):
        ret = dict()
        try:
            departmentList = list()
            for d in Department.objects.all():
                doctorList = self.getAllDoctor(d.id)
                idList = [item["doctorID"] for item in doctorList]
                # 获取当前日期
                current_date = timezone.now().date()

                # 获取本月的起始日期和结束日期
                start_of_month = datetime(current_date.year, current_date.month, 1)
                end_of_month = datetime(current_date.year, current_date.month + 1, 1) - timezone.timedelta(days=1)

                # 查询并求和
                result = DoctorWorkShift.objects.filter(doctor__id__in=idList,
                                                        shift__date__range=(start_of_month, end_of_month)) \
                    .aggregate(total_sum=Sum('total'),
                               available_sum=Sum('available'))
                if not result["total_sum"]:
                    total = 0
                    already = 0
                else:
                    total = result["total_sum"]
                    already = total - result["available_sum"]
                departmentList.append({
                    "departmentID": d.id,
                    "departmentName": d.name,
                    "intro": d.introduction,
                    "doctorList": doctorList,
                    "doctorNum": len(doctorList),
                    "total": total,
                    "already": already
                })
            ret["data"] = {
                "departmentList": departmentList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getOneDepartmentDoc(self, request):
        ret = dict()
        try:
            data = request.data
            departmentID = data.get("departmentID")
            department = Department.objects.get(id=departmentID)
            doctorList = list()
            for d in Doctor.objects.filter(department=department):
                doctorList.append({
                    "doctorID": d.id,
                    "doctorName": d.user.username,
                    "departmentID": d.department.id,
                    "departmentName": d.department.name,
                    "title": d.title,
                    "intro": d.intro,
                    "price": d.price,
                    "count": d.count
                })
            ret["data"] = {
                "doctorList": doctorList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getOneDoctor(self, request):
        ret = dict()
        try:
            data = request.data
            doctorID = data.get("doctorID")
            doctor = Doctor.objects.get(id=doctorID)
            current_day = datetime.today().date()
            three_days_after = current_day + timedelta(days=2)
            threeDays = list()
            for shift in DoctorWorkShift.objects.filter(shift__date__range=(current_day, three_days_after),
                                                        doctor=doctor).order_by("shift__date", "shift__time"):
                threeDays.append({
                    "date": str(shift.shift.date),
                    "time": shift.shift.time,
                    "total": shift.total,
                    "already": shift.total - shift.available
                })
            ret["data"] = {
                "doctorID": doctor.id,
                "doctorName": doctor.user.username,
                "departmentID": doctor.department.id,
                "departmentName": doctor.department.name,
                "title": doctor.title,
                "count": doctor.count,
                "area": doctor.area,
                "price": doctor.price,
                "intro": doctor.intro,
                "threeDays": threeDays
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def updateOneDoctor(self, request):
        ret = dict()
        try:
            data = request.data
            doctorID = data.get("doctorID")
            doctor = Doctor.objects.get(id=doctorID)
            title = data.get("title")
            area = data.get("area")
            intro = data.get("intro")
            price = data.get("price")
            if price <= 0:
                raise Exception("挂号费非负")
            doctor.title = title
            doctor.area = area
            doctor.intro = intro
            doctor.price = price
            doctor.save()
            ret["data"] = {
                "doctorID": doctor.id,
                "title": doctor.title,
                "area": doctor.area,
                "price": doctor.price,
                "intro": doctor.intro,
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def createPrescription(self, request):
        ret = dict()
        try:
            data = request.data
            name = data.get("name")
            price = data.get("price")
            approval_number = data.get("approval_number")
            production_unit = data.get("production_unit")
            if not name:
                raise Exception("处方名不能为空")
            if not approval_number:
                raise Exception("批准文号不能为空")
            if not production_unit:
                raise Exception("生产机构不能为空")
            if price <= 0:
                raise Exception("价格非正")
            prescription = Prescription.objects.create(prescription_name=name,
                                                       prescription_price=price,
                                                       approval_number=approval_number,
                                                       production_unit=production_unit)
            ret["data"] = {
                "id": prescription.prescription_id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def updatePrescription(self, request):
        ret = dict()
        try:
            data = request.data
            pid = data.get("id")
            name = data.get("name")
            price = data.get("price")
            approval_number = data.get("approval_number")
            production_unit = data.get("production_unit")
            if not name:
                raise Exception("处方名不能为空")
            if price <= 0:
                raise Exception("价格非正")
            if not approval_number:
                raise Exception("批准文号不能为空")
            if not production_unit:
                raise Exception("生产机构不能为空")
            prescription = Prescription.objects.get(prescription_id=pid)
            prescription.prescription_name = name
            prescription.prescription_price = price
            prescription.approval_number = approval_number
            prescription.production_unit = production_unit
            prescription.save()
            ret["data"] = {
                "id": prescription.prescription_id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def listAllPrescription(self, request):
        ret = dict()
        try:
            prescriptionList = list()
            for p in Prescription.objects.all():
                prescriptionList.append({
                    "id": p.prescription_id,
                    "approval_number": p.approval_number,
                    "name": p.prescription_name,
                    "production_unit": p.production_unit,
                    "price": p.prescription_price
                })
            ret["data"] = {
                "prescriptionList": prescriptionList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getOnePrescription(self, request):
        ret = dict()
        try:
            data = request.data
            pid = data.get("id")
            p = Prescription.objects.get(prescription_id=pid)
            ret["data"] = {
                "id": p.prescription_id,
                "approval_number": p.approval_number,
                "name": p.prescription_name,
                "english_name": p.english_name,
                "dosage_form": p.dosage_form,
                "specifications": p.specifications,
                "production_unit": p.production_unit,
                "price": p.prescription_price,

            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def createInspection(self, request):
        ret = dict()
        try:
            data = request.data
            name = data.get("name")
            price = data.get("price")
            departmentID = data.get("departmentID")
            detail = data.get("detail")
            if not name:
                raise Exception("检查名不能为空")
            if price <= 0:
                raise Exception("价格非正")
            department = Department.objects.get(id=departmentID)
            inspection = Inspection.objects.create(inspection_name=name,
                                                   inspection_price=price,
                                                   department=department,
                                                   detail=detail)
            ret["data"] = {
                "id": inspection.inspection_id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def updateInspection(self, request):
        ret = dict()
        try:
            data = request.data
            iid = data.get("id")
            name = data.get("name")
            price = data.get("price")
            departmentID = data.get("departmentID")
            detail = data.get("detail")
            if not name:
                raise Exception("检查名不能为空")
            if price <= 0:
                raise Exception("价格非正")
            department = Department.objects.get(id=departmentID)
            inspection = Inspection.objects.get(inspection_id=iid)
            inspection.inspection_name = name
            inspection.inspection_price = price
            inspection.department = department
            inspection.detail = detail
            inspection.save()
            ret["data"] = {
                "id": inspection.inspection_id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def listAllInspection(self, request):
        ret = dict()
        try:
            inspectionList = list()
            for i in Inspection.objects.all():
                inspectionList.append({
                    "id": i.inspection_id,
                    "name": i.inspection_name,
                    "department": i.department.name,
                    "price": i.inspection_price
                })
            ret["data"] = {
                "inspectionList": inspectionList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getOneInspection(self, request):
        ret = dict()
        try:
            data = request.data
            iid = data.get("id")
            i = Inspection.objects.get(inspection_id=iid)
            ret["data"] = {
                "id": i.inspection_id,
                "name": i.inspection_name,
                "department": i.department.name,
                "price": i.inspection_price,
                "detail": i.detail
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    @transaction.atomic
    def createDoctorShift(self, request):
        ret = dict()
        try:
            data = request.data
            shiftList = data.get("shiftList")
            retList = list()
            for item in shiftList:
                doctorID = item.get("doctorID")
                doctor = Doctor.objects.get(id=doctorID)
                date = datetime.strptime(item.get("date"), "%Y-%m-%d")
                time = int(item.get("time"))  # 0-上午,1-下午
                if time not in [0, 1]:
                    raise Exception("时间段参数非法")
                total = item.get("total")  # 总号数
                if total <= 0:
                    raise Exception("总号数非法")
                if WorkShift.objects.filter(date=date, time=time).count() == 0:
                    workShift = WorkShift.objects.create(date=date, time=time)
                else:
                    workShift = WorkShift.objects.get(date=date, time=time)
                doctorShift = DoctorWorkShift.objects.create(doctor=doctor,
                                                             shift=workShift,
                                                             total=total,
                                                             available=total)
                retList.append({
                    "shiftID": doctorShift.id,
                    "doctorID": doctor.id,
                    "doctorName": doctor.user.username,
                    "date": str(doctorShift.shift.date),
                    "time": time,
                    "total": total,
                    "available": total
                })
            ret["data"] = {
                "shiftList": retList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getDepartAllShift(self, request):
        ret = dict()
        try:
            data = request.data
            departmentID = data.get("departmentID")
            department = Department.objects.get(id=departmentID)
            date = datetime.strptime(data.get("date"), "%Y-%m-%d")
            # 获取本月的起始日期和结束日期
            start_of_month = datetime(date.year, date.month, 1)
            end_of_month = datetime(date.year, date.month + 1, 1) - timezone.timedelta(days=1)

            # 获取当前月份的年份和月份
            year = date.year
            month = date.month

            # 计算当前月份的天数
            days_in_month = calendar.monthrange(year, month)[1]
            shiftList = [[{"type": "warning", "content": None}, {"type": "success", "content": None}] for _ in range(days_in_month)]
            for shift in DoctorWorkShift.objects.exclude(state=1).filter(doctor__department=department,
                                                                         shift__date__range=(
                                                                                 start_of_month, end_of_month)):
                index = (shift.shift.date - start_of_month.date()).days
                type = shift.shift.time
                if shiftList[index][type]["content"] is None:
                    shiftList[index][type]["content"] = ""
                shiftList[index][type]["content"] += "{} ".format(shift.doctor.user.username)
            ret["data"] = {
                "shiftList": shiftList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getOneDayShift(self, request):
        ret = dict()
        try:
            data = request.data
            departmentID = data.get("departmentID")
            department = Department.objects.get(id=departmentID)
            date = datetime.strptime(data.get("date"), "%Y-%m-%d")

            shiftList = []
            for shift in DoctorWorkShift.objects.exclude(state=1).filter(doctor__department=department,
                                                                         shift__date=date):
                shiftList.append({
                    "shiftID": shift.id,
                    "doctorID": shift.doctor.id,
                    "doctorName": shift.doctor.user.username,
                    "date": str(shift.shift.date),
                    "time": shift.shift.time,
                    "total": shift.total,
                    "available": shift.available
                })
            ret["data"] = {
                "shiftList": shiftList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    @transaction.atomic
    def deleteShift(self, request):
        ret = dict()
        try:
            data = request.data
            departmentID = data.get("departmentID")
            department = Department.objects.get(id=departmentID)
            date = datetime.strptime(data.get("date"), "%Y-%m-%d")
            DoctorWorkShift.objects.filter(doctor__department=department, shift__date=date).delete()
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def deleteOneShift(self, request):
        ret = dict()
        try:
            data = request.data
            shiftID = data.get("shiftID")
            DoctorWorkShift.objects.get(id=shiftID).delete()
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getAllUnLeave(self, request):
        ret = dict()
        try:
            appList = list()
            for a in LeaveApplication.objects.filter(state=0):
                appList.append({
                    "id": a.id,
                    "department": a.doctor_shift.doctor.department.name,
                    "doctorName": a.doctor_shift.doctor.user.username,
                    "doctorShiftID": a.doctor_shift.id,
                    "type": a.apply_type,
                    "reason": a.reason,
                    "commitTime": str(a.commitTime.strftime("%Y-%m-%d %H:%M:%S")),
                    "leaveTime": str(a.doctor_shift.shift.date),
                    "time": a.doctor_shift.shift.time,
                    "workID": a.doctor_shift.doctor.workID,
                    "phone": a.doctor_shift.doctor.user.phone
                })
            ret["data"] = {
                "appList": appList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def getAllLeave(self, request):
        ret = dict()
        try:
            appList = list()
            for a in LeaveApplication.objects.exclude(state=0):
                appList.append({
                    "id": a.id,
                    "department": a.doctor_shift.doctor.department.name,
                    "doctorName": a.doctor_shift.doctor.user.username,
                    "doctorShiftID": a.doctor_shift.id,
                    "type": a.apply_type,
                    "reason": a.reason,
                    "commitTime": str(a.commitTime.strftime("%Y-%m-%d %H:%M:%S")),
                    "state": a.state,
                    "verifyTime": str(a.verifyTime.strftime("%Y-%m-%d %H:%M:%S")),
                    "verifyComment": a.verifyComment,
                    "leaveTime": str(a.doctor_shift.shift.date),
                    "time": a.doctor_shift.shift.time,
                    "workID": a.doctor_shift.doctor.workID,
                    "phone": a.doctor_shift.doctor.user.phone
                })
            ret["data"] = {
                "appList": appList
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)

    def verifyApp(self, request):
        ret = dict()
        try:
            data = request.data
            appID = data.get("appID")
            app = LeaveApplication.objects.get(id=appID)
            state = data.get("state")
            if state not in [1, 2]:
                raise Exception("审核意见非法")
            comment = data.get("verifyComment")
            app.state = state
            app.verifyComment = comment
            app.verifyTime = timezone.now()
            app.save()
            if state == 1:
                app.doctor_shift.state = 1
                app.doctor_shift.save()
            ret["data"] = {
                "appID": app.id
            }
            ret["code"] = 0
            ret["msg"] = "success"
        except Exception as e:
            ret["code"] = 1
            ret["msg"] = str(e)

        return Response(ret)


class NotifyViewSet(viewsets.ModelViewSet):
    def createNotification(self, request):
        time = datetime.strptime(request.data.get('time'), "%Y-%m-%d %H:%M:%S") if request.data.get('time') else timezone.now()
        Notification.objects.create(title=request.data.get('title'), content=request.data.get('content'), time=time, type=request.data.get('type'))
        return Response({'code': 200, 'msg': 'success'})

    def getAllNotification(self, request):
        return Response({'code': 200, 'msg': 'success', 'type': request.data.get('type'),
                         'data': [{'title': item.title, 'content': item.content, 'time': item.time, 'announcementID': item.id}
                                  for item in Notification.objects.filter(type=request.data.get('type')).order_by('-time')[:4]]})

    def deleteNotification(self, request):
        Notification.objects.get(id=request.data.get('id')).delete()
        return Response({'code': 200, 'msg': 'success'})
