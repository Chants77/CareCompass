from django.urls import path

from .views import *

urlpatterns = [
    path('admin/createDepartment/', AdminViewSet.as_view({'post': 'createDepartment'})),
    path('admin/updateDepartment/', AdminViewSet.as_view({'post': 'updateDepartment'})),
    path('admin/getAllDepartment/', AdminViewSet.as_view({'post': 'getAllDepartment'})),
    path('admin/getOneDepartmentDoc/', AdminViewSet.as_view({'post': 'getOneDepartmentDoc'})),
    path('admin/getOneDoctor/', AdminViewSet.as_view({'post': 'getOneDoctor'})),
    path('admin/updateOneDoctor/', AdminViewSet.as_view({'post': 'updateOneDoctor'})),
    path('admin/createPrescription/', AdminViewSet.as_view({'post': 'createPrescription'})),
    path('admin/updatePrescription/', AdminViewSet.as_view({'post': 'updatePrescription'})),
    path('admin/listAllPrescription/', AdminViewSet.as_view({'post': 'listAllPrescription'})),
    path('admin/getOnePrescription/', AdminViewSet.as_view({'post': 'getOnePrescription'})),
    path('admin/createInspection/', AdminViewSet.as_view({'post': 'createInspection'})),
    path('admin/updateInspection/', AdminViewSet.as_view({'post': 'updateInspection'})),
    path('admin/listAllInspection/', AdminViewSet.as_view({'post': 'listAllInspection'})),
    path('admin/getOneInspection/', AdminViewSet.as_view({'post': 'getOneInspection'})),
    path('admin/createDoctorShift/', AdminViewSet.as_view({'post': 'createDoctorShift'})),
    path('admin/getDepartAllShift/', AdminViewSet.as_view({'post': 'getDepartAllShift'})),
    path('admin/getOneDayShift/', AdminViewSet.as_view({'post': 'getOneDayShift'})),
    path('admin/deleteShift/', AdminViewSet.as_view({'post': 'deleteShift'})),
    path('admin/deleteOneShift/', AdminViewSet.as_view({'post': 'deleteOneShift'})),
    path('admin/getAllUnLeave/', AdminViewSet.as_view({'post': 'getAllUnLeave'})),
    path('admin/getAllLeave/', AdminViewSet.as_view({'post': 'getAllLeave'})),
    path('admin/verifyApp/', AdminViewSet.as_view({'post': 'verifyApp'})),
    path('admin/addAnnouncement/', NotifyViewSet.as_view({'post': 'createNotification'})),
    path('admin/allAnnouncement/', NotifyViewSet.as_view({'post': 'getAllNotification'})),
    path('admin/deleteAnnouncement/', NotifyViewSet.as_view({'post': 'deleteNotification'})),
]