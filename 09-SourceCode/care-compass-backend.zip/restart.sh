# killall -9 uwsgi
rm log.txt
service nginx restart
# uwsgi --ini uwsgi.ini
pid=$(ps -ef | grep "python manage.py" | awk 'NR==1{print $2}')
kill -9 $pid
nohup python manage.py runserver 0.0.0.0:8000 &
