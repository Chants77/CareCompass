USER="hospital"
PASSWORD="AX6rMXZbn8ZF48JD"
HOST="8.130.100.115"
DATABASE="hospital"

TABLES=$(mysql -u $USER -p$PASSWORD -h $HOST $DATABASE -e 'show tables' | awk '{ print $1}' | grep -v '^Tables' )
for t in $TABLES; do
    echo "Deleting $t table from $DATABASE database..."
    mysql -u $USER -p$PASSWORD -h $HOST $DATABASE -e "SET FOREIGN_KEY_CHECKS=0"
    mysql -u $USER -p$PASSWORD -h $HOST $DATABASE -e "SET FOREIGN_KEY_CHECKS=0; drop table if exists $t; SET FOREIGN_KEY_CHECKS=1;"
done
mysql -u $USER -p$PASSWORD -h $HOST $DATABASE -e "SET FOREIGN_KEY_CHECKS=1"

echo "All tables have been deleted from $DATABASE database."