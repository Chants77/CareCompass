rm -rf Admin/migrations/*.*
rm -rf Consultation/migrations/*.*
rm -rf Treatment/migrations/*.*
rm -rf User/migrations/*.*

touch User/migrations/__init__.py
touch Admin/migrations/__init__.py
touch Consultation/migrations/__init__.py
touch Treatment/migrations/__init__.py

#read -p "你确定要删除所有表吗？(Y/N) " -n 1 -r
#echo
#
#if [[ $REPLY =~ ^[Yy]$ ]]
#then
#    bash restore_database.sh
#fi

python manage.py makemigrations
python manage.py migrate

