from django.utils import timezone

from django.db import models

from User.models import User, Doctor, Bill


class WorkShift(models.Model):
    id = models.AutoField(primary_key=True)
    date = models.DateField(verbose_name="日期")      # 排班日期
    time = models.IntegerField(verbose_name="时间段")  # 0-上午，1-下午


class Appointment(models.Model):
    id = models.AutoField(primary_key=True)
    patient = models.ForeignKey(User, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    commitTime = models.DateTimeField("挂号时间", default=timezone.now)
    appointTime = models.ForeignKey(WorkShift, on_delete=models.CASCADE)
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE,null=True)
    isOnTime = models.BooleanField(verbose_name=u'是否按时就诊', default=False)
    isExpired = models.BooleanField(verbose_name=u'是否已过期', default=False)


class DoctorWorkShift(models.Model):
    id = models.AutoField(primary_key=True)
    doctor = models.ForeignKey(Doctor, verbose_name=u'医生', on_delete=models.CASCADE)
    shift = models.ForeignKey(WorkShift, verbose_name=u'时间段', on_delete=models.CASCADE)
    total = models.IntegerField(verbose_name=u'总号数', default=0)
    available = models.IntegerField(verbose_name=u'剩余号数', default=0)
    state = models.IntegerField(verbose_name="是否被请假", default=0)  # 0-未请假，1-被请假
