from django.urls import path

from .views import *

urlpatterns = [
    path('department/list/', AppointViewSet.as_view({'post': 'getDepartmentList'})),
    path('department/workshift/', AppointViewSet.as_view({'post': 'getDepartmentShift'})),
    path('patient/appointment/create/', AppointViewSet.as_view({'post': 'appoint'})),
    path('patient/appointment/create/bill/', AppointViewSet.as_view({'post': 'createBill'})),
    path('patient/appointment/cancel/', AppointViewSet.as_view({'post': 'cancelAppointment'})),
    path('patient/appointment/list/', AppointViewSet.as_view({'post': 'getAppointmentList'})),
    path('patient/consultation/list/', ConsultViewSet.as_view({'post': 'getConsultList'})),
    path('patient/consultation/get/', ConsultViewSet.as_view({'post': 'getConsultation'})),
    path('patient/bill/get/', PaymentViewSet.as_view({'post': 'getBillList'})),
    path('test/time/', AppointViewSet.as_view({'post': 'testTime'})),
    path('patient/bill/getSingle/', PaymentViewSet.as_view({'post': 'getBill'})),
    path('patient/bill/create/', PaymentViewSet.as_view({'post': 'createBill'})),
    path('patient/bill/pay/', PaymentViewSet.as_view({'post': 'payBill'})),
]
