from datetime import datetime, timedelta

from Consultation.models import Appointment


# @transaction.atomic
# def updateAppointmentStatus():
#     date = datetime.today()
#     dateMonthAgo = date + timedelta(days=-30)
#     time = 0 if datetime.now().hour < 12 else 1
#     workShift = WorkShift.objects.get(date=date, time=time)
#     for appointment in Appointment.objects.filter(appointTime=workShift):
#         appointment.isExpired = True
#         appointment.save()
#     for patient in User.objects.filter(identity='patient'):
#         missTime = Appointment.objects.filter(user=patient, appointTime__date__gte=dateMonthAgo, isExpired=True, isOnTime=False).count()
#         patient.isBan = missTime >= 4
#         patient.save()


def deleteUnpaidAppointment():
    time_low = datetime.now() + timedelta(minutes=-15)
    for appointment in Appointment.objects.filter(bill__pay_time__isnull=True, bill__create_time__lte=time_low):
        appointment.bill.delete()
        # appointment.delete()
