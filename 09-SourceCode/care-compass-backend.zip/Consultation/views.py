import json
import traceback
import requests
import CareCompass.settings

from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views import View
from rest_framework import viewsets
from rest_framework.response import Response
from django.utils import timezone

from User.models import *
from Admin.models import MedicalRecord, InspectionForm, PrescriptionForm
from .models import *
from datetime import datetime, timedelta
import random
from django.core.cache import cache
from django.db import connection, transaction
from django.db.models import Count
from django.core.paginator import Paginator


# from Work.api import removeSubmissions

class AppointViewSet(viewsets.ModelViewSet):
    def getDepartmentList(self, request):
        result = []
        for department in Department.objects.all():
            result.append({
                'id': department.id,
                'name': department.name,
                'description': department.introduction
            })
        return Response(result)

    def getDepartmentShift(self, request):
        department = request.data.get('departmentID')

        def getShiftList(date):
            ans = {
                "morning": [],
                "afternoon": []
            }
            for shift in DoctorWorkShift.objects.exclude(state=1).filter(shift__date=date, doctor__department__id=department):
                item = {"doctorID": shift.doctor.id, "doctorName": shift.doctor.user.username,
                        "doctorTitle": shift.doctor.title, "available": shift.available, "price": shift.doctor.price}
                if shift.shift.time == 0:
                    ans['morning'].append(item)
                else:
                    ans['afternoon'].append(item)
            return ans

        today = datetime.today() + timedelta(days=1)
        tomorrow = today + timedelta(days=1)
        third = tomorrow + timedelta(days=1)
        result = {
            "today": getShiftList(today),
            "tomorrow": getShiftList(tomorrow),
            "lastDay": getShiftList(third)
        }
        return Response(result)

    @transaction.atomic
    def appoint(self, request):
        ret = {'code': 200, 'msg': 'success'}
        # request.uid = 1
        user = User.objects.get(id=request.uid)
        user.isBan = Appointment.objects.filter(patient=user, appointTime__date__gte=timezone.now()-timedelta(days=30), isOnTime=False).count() >= 5
        user.save()
        if user.isBan:
            ret = {'code': 400, 'msg': '失约次数过多，已禁止挂号'}
            return Response(ret)
        if Appointment.objects.filter(patient=user, bill__isnull=True).count() > 0 or Appointment.objects.filter(patient=user, bill__isnull=False, bill__pay_time__isnull=True).count() > 0:
            ret = {'code': 400, 'msg': '有未完成挂号'}
            return Response(ret)
        date = datetime.strptime(request.data.get('date'), "%Y-%m-%d")
        time = int(request.data.get('time'))
        doctor = Doctor.objects.get(id=request.data.get('doctorID'))
        if Appointment.objects.filter(doctor=doctor, appointTime__date=date, appointTime__time=time, patient=user).count() > 0:
            ret = {'code': 400, 'msg': '已经挂过号'}
            return Response(ret)
        try:
            doctorWorkShift = DoctorWorkShift.objects.get(doctor=doctor, shift__date=date, shift__time=time)
        except:
            ret = {'code': 400, 'msg': '无对应排班信息'}
        else:
            if doctorWorkShift.available == 0:
                ret = {'code': 400, 'msg': '预约已满'}
            else:
                # bill = Bill.objects.create(price=doctor.price, create_time=timezone.now())
                obj = Appointment.objects.create(patient=user, doctor=doctor, appointTime=doctorWorkShift.shift)
                obj.save()
                ret['appointmentID'] = obj.id
        return Response(ret)

    @transaction.atomic
    def createBill(self, request):
        ret = {'code': 200, 'msg': 'success'}
        user = User.objects.get(id=request.uid)
        try:
            appointment = Appointment.objects.get(id=request.data.get('appointmentID'))
            bill = Bill.objects.create(price=appointment.doctor.price, create_time=timezone.now())
            appointment.bill = bill
            appointment.save()
        except:
            ret = {'code': 400, 'msg': '预约号有误'}
        return Response(ret)

    @transaction.atomic
    def getAppointmentList(self, request):
        ret = {'code': 200, 'msg': 'success', 'content': []}
        user = User.objects.get(pk=int(request.uid))
        # print(user.id)
        def getOrder(appointment):
            if appointment.bill is None or appointment.bill.pay_time is None:
                return -1
            return Appointment.objects.filter(appointTime=appointment.appointTime, bill__pay_time__isnull=False, bill__pay_time__lte=appointment.bill.pay_time).count()
        for item in Appointment.objects.filter(patient=user):
            ret['content'].append({
                'id': item.id,
                'doctorID': item.doctor.id,
                'doctorName': item.doctor.user.username,
                'departmentID': item.doctor.department.id,
                'departmentName': item.doctor.department.name,
                'billID': item.bill.id,
                'price': item.bill.price,
                'commitTime': item.commitTime,
                'appointDate': item.appointTime.date,
                'appointTime': ['上午', '下午'][item.appointTime.time],
                'appointOrder': getOrder(appointment=item)
            })
        return Response(ret)

    def testTime(self, request):
        time = timezone.now()
        return Response({'time': time})

    @transaction.atomic
    def cancelAppointment(self, request):
        user = User.objects.get(id=int(request.uid))
        try:
            appointment = Appointment.objects.get(id=int(request.data.get('id')))
            if appointment.isExpired:
                result = {'code': 400, 'msg': '挂号已过期'}
                return Response(result)
            if appointment.patient != user:
                result = {'code': 400, 'msg': '无权限'}
                return Response(result)
        except:
            result = {'code': 400, 'msg': '无挂号信息'}
        else:
            doctorWorkShift = DoctorWorkShift.objects.get(doctor=appointment.doctor, shift=appointment.appointTime)
            if appointment.bill.pay_time is not None:
                doctorWorkShift.available += 1
                appointment.doctor.count -= 1
                appointment.doctor.save()
                doctorWorkShift.save()
            appointment.bill.delete()
            appointment.delete()
            result = {'code': 200, 'msg': 'success'}
        return JsonResponse(result)


class ConsultViewSet(viewsets.ModelViewSet):
    def getConsultList(self, request):
        user = User.objects.get(id=request.uid)
        result = []
        for record in MedicalRecord.objects.filter(appointment__patient=user):
            result.append({
                'id': record.record_id, 'departmentName': record.appointment.doctor.department.name,
                'departmentID': record.appointment.doctor.department.id, 'doctorName': record.appointment.doctor.user.username,
                'doctorID': record.appointment.doctor.id, 'date': record.appointment.appointTime.date,
                'time': record.appointment.appointTime.time
            })
        return Response(result)

    def getConsultation(self, request):
        user = User.objects.get(id=request.uid)
        record = MedicalRecord.objects.get(user=user, id=request.data['recordID'])
        return Response({'id': request.data['recordID'], 'departmentName': record.appointment.doctor.department.name,
                         'departmentID': record.appointment.doctor.department.id,
                         'doctorName': record.appointment.doctor,
                         'doctorID': record.appointment.doctor.id, 'detail': record.detail})


class PaymentViewSet(viewsets.ModelViewSet):
    def getBillList(self, request):
        user = User.objects.get(id=request.data.get('UserID'))
        result = {'Appointment': [], 'Inspection': [], 'Prescription': []}
        for record in Appointment.objects.filter(patient=user):
            try:
                recordID = MedicalRecord.objects.get(appointment=record).id
            except:
                recordID = -1
            if record.bill:
                result['Appointment'].append({
                    'id': record.bill.id, 'price': record.bill.price, 'appointmentID': record.id,
                    'createTime': record.bill.create_time, 'payTime': record.bill.pay_time, 'medicalRecordID': recordID
                })
        for record in InspectionForm.objects.filter(medical_record__appointment__patient=user):
            try:
                recordID = MedicalRecord.objects.get(inspectionform=record).id
            except:
                recordID = -1
            if record.bill:
                result['Inspection'].append({
                    'id': record.bill.id, 'price': record.bill.price, 'inspectionID': record.id,
                    'createTime': record.bill.create_time, 'payTime': record.bill.pay_time, 'medicalRecordID': recordID
                })
        for record in PrescriptionForm.objects.filter(medical_record__appointment__patient=user):
            try:
                recordID = MedicalRecord.objects.get(prescriptionform=record).id
            except:
                recordID = -1
            if record.bill:
                result['Prescription'].append({
                    'id': record.bill.id, 'price': record.bill.price, 'prescriptionID': record.id,
                    'createTime': record.bill.create_time, 'payTime': record.bill.pay_time, 'medicalRecordID': recordID
                })
        return Response(result)

    def getBill(self, request):
        user = User.objects.get(id=request.uid)
        ret = {'code': 200, 'msg': 'success', 'data': {}}
        try:
            bill = Bill.objects.get(id=request.data.get('billID'))
        except:
            ret['code'] = 400
            ret['msg'] = 'Invaild billID'
        else:
            data = {'id': bill.id, 'price': bill.price, 'createTime': bill.create_time, 'payTime': bill.pay_time}
            for FormType, formName in [(Appointment, 'appointment'), (InspectionForm, 'inspection'), (PrescriptionForm, 'prescription')]:
                dataList = FormType.objects.filter(bill=bill)
                if dataList.count() > 0:
                    data['billType'] = formName
                    data['typeID'] = dataList[0].id
                    break
            if data.get('billType') is None:
                ret['code'] = 400
                ret['msg'] = 'billID reference not found'
                ret['data'] = {}
            ret['data'] = data
        return Response(ret)

    @transaction.atomic
    def createBill(self, request):
        user = User.objects.get(id=request.uid)
        price = request.data.get('billPrice')
        bill = Bill.objects.create(price=price, create_time=timezone.now())
        billType = request.data.get('billType')
        typeID = request.data.get('typeID')
        ret = {'code': 200, 'msg': 'success', 'billID': bill.id}
        formDict = {'appointment': Appointment, 'inspection': InspectionForm, 'prescription': PrescriptionForm}
        if formDict.get(billType) is not None:
            obj = formDict[billType].objects.get(id=typeID)
            obj.bill = bill
            obj.save()
        else:
            return Response({'code': 400, 'msg': 'Illegal billType'})
        return Response(ret)


    @transaction.atomic
    def payBill(self, request):
        user = User.objects.get(id=request.uid)
        bill_type = request.data.get('billType')
        id = request.data.get('billID')
        judge = (bill_type == 'appointment' and Appointment.objects.filter(patient=user, bill__id=id).count() > 0) \
            or (bill_type == 'inspection' and InspectionForm.objects.filter(medical_record__appointment__patient=user, bill__id=id).count() > 0) \
            or (bill_type == 'prescription' and PrescriptionForm.objects.filter(medical_record__appointment__patient=user, bill__id=id).count() > 0)
        if not judge:
            return Response({'code': 400, 'msg': '支付信息有误'})
        try:
            bill = Bill.objects.get(id=id)
            bill.pay_time = timezone.now()
            bill.save()
            if bill_type == 'appointment':
                appointment = Appointment.objects.get(bill=bill)
                appointment.doctor.count += 1
                appointment.doctor.save()
                doctorWorkShift = DoctorWorkShift.objects.get(doctor=appointment.doctor, shift=appointment.appointTime)
                doctorWorkShift.available -= 1
                doctorWorkShift.save()
        except:
            return Response({'code': 400, 'msg': '支付失败'})
        return Response({'code': 200, 'msg': '支付成功'})

