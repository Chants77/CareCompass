from rest_framework.viewsets import ModelViewSet


class BaseViewSet(ModelViewSet):
    def dispatch(self, request, *args, **kwargs):
        lookup_param = request.GET.get(self.lookup_url_kwarg, None)
        if lookup_param:
            kwargs[self.lookup_url_kwarg] = lookup_param
        return super(ModelViewSet, self).dispatch(request, *args, **kwargs)