from rest_framework.views import exception_handler
from rest_framework.renderers import JSONRenderer

from rest_framework import pagination
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination


class CustomRenderer(JSONRenderer):
    def render(self, data, accepted_media_type=None, renderer_context=None):
        if renderer_context:

            if isinstance(data, dict):
                msg = data.pop('msg', 'success')
                code = data.pop(
                    'code', renderer_context["response"].status_code)
                if 'results' in data:
                    data = data['results']
            else:
                msg = 'success'
                code = renderer_context["response"].status_code

            # 自定义返回的格式
            ret = {
                'msg': msg,
                'code': code,
                'data': data,
            }
            # 返回JSON数据
            return super().render(ret, accepted_media_type, renderer_context)
        else:
            return super().render(data, accepted_media_type, renderer_context)


class StandardResultsSetPagination(PageNumberPagination):
    page_size_query_param = 'limit'


def custom_exception_handler(exc, context):
    if isinstance(exc, AttributeError):
        return Response(data={'code': 500, 'msg': '请重新登录'}, status=500)
    response = exception_handler(exc, context)
    return response
