import re

from django.http import JsonResponse
from django.utils.deprecation import MiddlewareMixin

from User.jwt_token import check_token


class LoginCheckMidware(MiddlewareMixin):
    def process_request(self, request):
        pattern = r'^(/login|/register|/forget)'
        match = re.match(pattern, request.path)
        if match:
            return
        token = request.META.get('HTTP_TOKEN', None)
        # 可以按admin前缀 统一鉴权一下
        if token is not None:
            user = check_token(token)
            if user is not None:
                request.uid = user.id
            else:
                return JsonResponse({"code": 462, "msg": "账号在其他地方登录"})
